﻿#ifndef _user_uart_h
#define	_user_uart_h

extern void uart_send_byte(unsigned char data);



#endif
