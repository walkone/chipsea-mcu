﻿//============================================
// filename: main.c
// chip    : CSU18MB86
// author  :
// date    : 2019-03-07

// 代码选项，勾选内部14.7MHz时钟
// 默认指令周期(CPUCLK)：2MHz
// UART波特率115200


//============================================
#include "CSU18MB86.h"
#include "CS_18MB86_Init.h"
#include "user_uart.h"

sbit b_10ms;
unsigned char Counter;
unsigned char TestE2_Write[10]={0,1,2,3,4,5,6,7,8,9};
unsigned char TestE2_Read[10];

//============================================
// program start
//============================================
void main()
{
	IO_Init();
	
	//内部E2PROM读写测试
	MB86_E2PROM_Write(80,TestE2_Write,10); //,在地址50，写10个数据（在线仿真可实时观察E2PROM）
	MB86_E2PROM_Read(80,TestE2_Read,10);   //在地址50，读10个数据
	
	Uart_Init(115200);	//波特率115200
	ADC24bit_Init();    //配置详见函数
	Timer0_Init();		//定时10ms
	Timer1_Init();		//在PT4.1输出PWM，50%占空比
//	uart_send_byte(0x55);  //test
	
	while(1)
	{
		if(b_10ms == 1)
		{
			b_10ms = 0;
			if(++Counter >= 50)
			{
				Counter = 0;
				uart_send_byte(ADOH);
				uart_send_byte(ADOL);
				uart_send_byte(ADOLL);
			}
		}
	}
}




//============================================
// interrupt function
//============================================
void INT_FUNCTION(void) interrupt
{
	if(URRIF)
	{
		URRIF = 0;	
	}
	else if(ADIF)
	{
		ADIF =0;
	}
	else if(TM0IF)
	{
		TM0IF = 0;
		b_10ms = 1;
//		PT2 ^= 0x01;   //test
	}
	else if(TM1IF)
	{
		TM1IF = 0;
	}
	else
	{
//		INTF = 0;
//		INTF2 = 0;
	}
	
}
