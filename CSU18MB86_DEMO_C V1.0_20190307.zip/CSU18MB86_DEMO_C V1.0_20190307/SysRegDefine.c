﻿//==============================================
// Date:2018-11-05
// Version: V1.0.0 
//==============================================

//Data Memory Organization 00h-08h
volatile unsigned char IND0             @ 0x00;     //{ IND0 }
volatile unsigned char IND1             @ 0x01;     //{ IND1 }
volatile unsigned char FSR0             @ 0x02;     //{ FSR0 }
volatile unsigned char FSR1             @ 0x03;     //{ FSR1 }
volatile unsigned char STATUS           @ 0x04;     //{ 0, 0, 0, PD, TO, DC, C, Z }
volatile unsigned char WORK             @ 0x05;     //{ WORK }
volatile unsigned char INTF             @ 0x06;     //{ 0, 0, TM1IF, TM0IF, AD2IF, ADIF, E1IF, E0IF }
volatile unsigned char INTE             @ 0x07;     //{ GIE, 0, TM1IE, TM0IE, AD2IE, ADIE, E1IE, E0IE }
volatile unsigned char BSR              @ 0x08;     //{ IRP0, IRP1, 0, 0, 0, 0, PAGE1, PAGE0 }

//Peripheral special registers 0Ah-7Fh
volatile unsigned char EADRH            @ 0x0A;     //{ 0, 0, PARH[5:0] }
volatile unsigned char EADRL            @ 0x0B;     //{ PARL[7:0] }
volatile unsigned char EDAT             @ 0x0C;     //{ EDAT[7:0] }
volatile unsigned char EOPEN            @ 0x0D;     //{ EOPEN[7:0] }
volatile unsigned char WDTCON           @ 0x0E;     //{ WDTEN, 0, 0, 0, 0, WDTS[2:0] }
volatile unsigned char WDTIN            @ 0x0F;     //{ WDTIN[7:0] }
volatile unsigned char ADOH             @ 0x10;     //{ ADO[23:16] }
volatile unsigned char ADOL             @ 0x11;     //{ ADO[15:8] }
volatile unsigned char ADOLL            @ 0x12;     //{ ADO[7:0] }
volatile unsigned char ADCON            @ 0x13;     //{ ADM, 0, 0, 0, ADSC, ADM[2:0] }
volatile unsigned char MCK              @ 0x14;     //{ 0, 0, 0, 0, 0, M2_CK, M1_CK, 0 }
volatile unsigned char PCK              @ 0x15;     //{ 0, 0, 0, 0, 0, S_beep[1:0], 0 }
volatile unsigned char NETA             @ 0x18;     //{ SINL[1:0], 0, CM_SEL, 0, 0, 0, 0 }
volatile unsigned char NETC             @ 0x1A;     //{ CHOPM[1:0], 0, 0, ADG[1:0], ADEN, 0 }
volatile unsigned char NETE             @ 0x1C;     //{ LDOS[1:0], 0, SILB[2:0], ENLB, LB_RST_CON }
volatile unsigned char NETF             @ 0x1D;     //{ 0, 0, LDOEN, 0, 0, BGID[1:0], 0 }
volatile unsigned char SVD              @ 0x1F;     //{ 0, 0, 0, 0, 0, 0, 0, LBOUT }
volatile unsigned char PT1              @ 0x20;     //{ 0, 0, 0, 0, PT1[3:0] }
volatile unsigned char PT1EN            @ 0x21;     //{ 0, 0, 0, 0, PT1EN[3:0] }
volatile unsigned char PT1PU            @ 0x22;     //{ 0, 0, 0, 0, PT1PU[3:0] }
volatile unsigned char AIENB            @ 0x23;     //{ AIENB3, 0, 0, AIENB2, AIENB1, 0, 0, 0 }
volatile unsigned char PT2              @ 0x24;     //{ PT2[7:0] }
volatile unsigned char PT2EN            @ 0x25;     //{ PT2EN[7:0] }
volatile unsigned char PT2PU            @ 0x26;     //{ PT2PU[7:0] }
volatile unsigned char PT4              @ 0x27;     //{ PT4[7:0] }
volatile unsigned char PT4EN            @ 0x28;     //{ PT4EN[7:0] }
volatile unsigned char PT4PU            @ 0x29;     //{ PT4PU[7:0] }
volatile unsigned char PT1CON           @ 0x2D;     //{ BZEN, 0, 0, 0, E1M[1:0], E0M[1:0] }
volatile unsigned char PT2CON           @ 0x2E;     //{ PT2CON[7:0] }
volatile unsigned char PTINT            @ 0x2F;     //{ PTW1[3:0], PTW0[3:0] }
volatile unsigned char INTF2            @ 0x32;     //{ 0, 0, 0, 0, RTCIF, SPIIF, URTIF, URRIF }
volatile unsigned char INTE2            @ 0x33;     //{ 0, 0, 0, 0, RTCIE, SPIIE, URTIE, URRIE }
volatile unsigned char TM0CON           @ 0x34;     //{ T0EN, T0RATE[2:0], 0, T0RSTB, 0, T0SEL }
volatile unsigned char TM0IN            @ 0x35;     //{ TM0IN[7:0] }
volatile unsigned char TM0CNT           @ 0x36;     //{ TM0CNT[7:0] }
volatile unsigned char TM1CON           @ 0x37;     //{ T1EN, T1RATE[2:0], T1CKS, T1RSTB, T1OUT, PWM1OUT }
volatile unsigned char TM1IN            @ 0x38;     //{ TM1IN[7:0] }
volatile unsigned char TM1CNT           @ 0x39;     //{ TM1CNT[7:0] }
volatile unsigned char TM1R             @ 0x3A;     //{ TM1R[7:0] }
volatile unsigned char LED1             @ 0x3B;     //{ LED1[7:0] }
volatile unsigned char LED2             @ 0x3C;     //{ LED2[7:0] }
volatile unsigned char LED3             @ 0x3D;     //{ LED3[7:0] }
volatile unsigned char LED4             @ 0x3E;     //{ LED4[7:0] }
volatile unsigned char LED5             @ 0x3F;     //{ LED5[7:0] }
volatile unsigned char LED6             @ 0x40;     //{ LED6[7:0] }
volatile unsigned char LED7             @ 0x41;     //{ LED7[7:0] }
volatile unsigned char LEDCON1          @ 0x42;     //{ LED_CURRENT[2:0], LCD_DUTY[1:0], LEDCLKS[1:0], LED_PMODE }
volatile unsigned char LEDCON2          @ 0x43;     //{ 0, 0, 0, 0, 0, 0, 0, LEDEN }
volatile unsigned char CHPCON           @ 0x44;     //{ 0, 0, 0, CHPVS, 0, CHPCLKS[1:0], CHPEN }
volatile unsigned char AD2OH            @ 0x48;     //{ AD2EN, 0, 0, 0, 0, 0, AD2O[9:8] }
volatile unsigned char AD2OL            @ 0x49;     //{ AD2O[7:0] }
volatile unsigned char FILCON           @ 0x4A;     //{ 0, 0, 0, FIL2_EN, 0, 0, 0, FIL1_EN }
volatile unsigned char DTHREH           @ 0x4B;     //{ DATA_THRE[15:8] }
volatile unsigned char DTHREL           @ 0x4C;     //{ DATA_THRE[7:0] }
volatile unsigned char NTHRE            @ 0x4D;     //{ 0, 0, NTHRE[5:0] }
volatile unsigned char NCON             @ 0x4E;     //{ 0, 0, 0, 0, 0, NSEL[2:0] }
volatile unsigned char SPICFG           @ 0x50;     //{ SPIEN, MSTEN, CKPHA, CKPOL, MULMST, WIREMOD, SPIBSY, SPIRST }
volatile unsigned char SPICN            @ 0x51;     //{ SLVSEL, WCOL, MODCOL, 0, 0, 0, 0, 0 }
volatile unsigned char SPICKR           @ 0x52;     //{ SCR[7:0] }
volatile unsigned char SPIDAT           @ 0x53;     //{ SPIDAT[7:0] }
volatile unsigned char TEMPC            @ 0x59;     //{ TEMPC[7:0] }
volatile unsigned char RTCCON           @ 0x60;     //{ LIR, 0, RTCCON_24hr_12hr, 0, RTCEN, 0, 0, 0 }
volatile unsigned char RTCAER           @ 0x61;     //{ AER[7:0] }
volatile unsigned char RTCYEAR          @ 0x62;     //{ RTCYEAR_10YEAR[7:4], RTCYEAR_1YEAR[3:0] }
volatile unsigned char RTCMON           @ 0x63;     //{ 0, 0, 0, RTCMON_10MON, RTCMON_1MON[3:0] }
volatile unsigned char RTCDAY           @ 0x64;     //{ 0, 0, RTCDAY_10DAY[5:4], RTCDAY_1DAT[3:0] }
volatile unsigned char RTCHOUR          @ 0x65;     //{ 0, 0, RTCHOUR_10HOUR10[5:4], RTCHOUR_1HOUR[3:0] }
volatile unsigned char RTCMIN           @ 0x66;     //{ 0, RTCMIN_10MIN[6:4], RTCMIN_1MIN[3:0] }
volatile unsigned char RTCSEC           @ 0x67;     //{ 0, RTCSEC_10SEC[6:4], RTCSEC_1SEC[3:0] }
volatile unsigned char RTCDWR           @ 0x68;     //{ 0, 0, 0, 0, 0, DWR[2:0] }
volatile unsigned char INTEGER          @ 0x69;     //{ 0, 0, 0, 0, INTEGER[3:0] }
volatile unsigned char FRACTION         @ 0x6A;     //{ 0, 0, FRACTION[5:0] }
volatile unsigned char WDT_C            @ 0x6D;     //{ 0, 0, 0, 0, 0, WDT_C[2:0] }
volatile unsigned char IOSC_C           @ 0x6E;     //{ IOSC_C[7:0] }
volatile unsigned char VS_C             @ 0x6F;     //{ 0, 0, 0, 0, VS_C[3:0] }
volatile unsigned char TMODE            @ 0x71;     //{ sim_rst, 0, 0, 0, 0, 0, TMOD[1:0] }
volatile unsigned char SCON1            @ 0x7A;     //{ SM0, SM1, SM2, REN, TB8, RB8, UART_SEL, UARTEN }
volatile unsigned char SCON2            @ 0x7B;     //{ SMOD, UARTCLKS, 0, 0, 0, 0, 0, 0 }
volatile unsigned char SBUF             @ 0x7C;     //{ SBUF }
volatile unsigned char LEDTEST1         @ 0x7D;     //{ LEDTEST1[7:0] }
volatile unsigned char METCH            @ 0x7E;     //{ METCH[7:0] }
volatile unsigned char LEDTEST2         @ 0x7F;     //{ LEDTEST2[7:0] }

//-------------------------------------------------------
//  STATUS register bit map
//-------------------------------------------------------
volatile sbit Z                         @ 0x04*8+0;
volatile sbit C                         @ 0x04*8+1;
volatile sbit DC                        @ 0x04*8+2;
volatile sbit TO                        @ 0x04*8+3;
volatile sbit PD                        @ 0x04*8+4;

//-------------------------------------------------------
//  INTF register bit map
//-------------------------------------------------------
volatile sbit E0IF                      @ 0x06*8+0;
volatile sbit E1IF                      @ 0x06*8+1;
volatile sbit ADIF                      @ 0x06*8+2;
volatile sbit AD2IF                     @ 0x06*8+3;
volatile sbit TM0IF                     @ 0x06*8+4;
volatile sbit TM1IF                     @ 0x06*8+5;

//-------------------------------------------------------
//  INTE register bit map
//-------------------------------------------------------
volatile sbit E0IE                      @ 0x07*8+0;
volatile sbit E1IE                      @ 0x07*8+1;
volatile sbit ADIE                      @ 0x07*8+2;
volatile sbit AD2IE                     @ 0x07*8+3;
volatile sbit TM0IE                     @ 0x07*8+4;
volatile sbit TM1IE                     @ 0x07*8+5;
volatile sbit GIE                       @ 0x07*8+7;

//-------------------------------------------------------
//  BSR register bit map
//-------------------------------------------------------
volatile sbit PAGE0                     @ 0x08*8+0;
volatile sbit PAGE1                     @ 0x08*8+1;
volatile sbit IRP1                      @ 0x08*8+6;
volatile sbit IRP0                      @ 0x08*8+7;

//-------------------------------------------------------
//  EADRH register bit map
//-------------------------------------------------------
volatile sbit PARH_0                    @ 0x0A*8+0;
volatile sbit PARH_1                    @ 0x0A*8+1;
volatile sbit PARH_2                    @ 0x0A*8+2;
volatile sbit PARH_3                    @ 0x0A*8+3;
volatile sbit PARH_4                    @ 0x0A*8+4;
volatile sbit PARH_5                    @ 0x0A*8+5;

//-------------------------------------------------------
//  EADRL register bit map
//-------------------------------------------------------
volatile sbit PARL_0                    @ 0x0B*8+0;
volatile sbit PARL_1                    @ 0x0B*8+1;
volatile sbit PARL_2                    @ 0x0B*8+2;
volatile sbit PARL_3                    @ 0x0B*8+3;
volatile sbit PARL_4                    @ 0x0B*8+4;
volatile sbit PARL_5                    @ 0x0B*8+5;
volatile sbit PARL_6                    @ 0x0B*8+6;
volatile sbit PARL_7                    @ 0x0B*8+7;

//-------------------------------------------------------
//  EDAT register bit map
//-------------------------------------------------------
volatile sbit EDAT_0                    @ 0x0C*8+0;
volatile sbit EDAT_1                    @ 0x0C*8+1;
volatile sbit EDAT_2                    @ 0x0C*8+2;
volatile sbit EDAT_3                    @ 0x0C*8+3;
volatile sbit EDAT_4                    @ 0x0C*8+4;
volatile sbit EDAT_5                    @ 0x0C*8+5;
volatile sbit EDAT_6                    @ 0x0C*8+6;
volatile sbit EDAT_7                    @ 0x0C*8+7;

//-------------------------------------------------------
//  EOPEN register bit map
//-------------------------------------------------------
volatile sbit EOPEN_0                   @ 0x0D*8+0;
volatile sbit EOPEN_1                   @ 0x0D*8+1;
volatile sbit EOPEN_2                   @ 0x0D*8+2;
volatile sbit EOPEN_3                   @ 0x0D*8+3;
volatile sbit EOPEN_4                   @ 0x0D*8+4;
volatile sbit EOPEN_5                   @ 0x0D*8+5;
volatile sbit EOPEN_6                   @ 0x0D*8+6;
volatile sbit EOPEN_7                   @ 0x0D*8+7;

//-------------------------------------------------------
//  WDTCON register bit map
//-------------------------------------------------------
volatile sbit WDTS_0                    @ 0x0E*8+0;
volatile sbit WDTS_1                    @ 0x0E*8+1;
volatile sbit WDTS_2                    @ 0x0E*8+2;
volatile sbit WDTEN                     @ 0x0E*8+7;

//-------------------------------------------------------
//  WDTIN register bit map
//-------------------------------------------------------
volatile sbit WDTIN_0                   @ 0x0F*8+0;
volatile sbit WDTIN_1                   @ 0x0F*8+1;
volatile sbit WDTIN_2                   @ 0x0F*8+2;
volatile sbit WDTIN_3                   @ 0x0F*8+3;
volatile sbit WDTIN_4                   @ 0x0F*8+4;
volatile sbit WDTIN_5                   @ 0x0F*8+5;
volatile sbit WDTIN_6                   @ 0x0F*8+6;
volatile sbit WDTIN_7                   @ 0x0F*8+7;

//-------------------------------------------------------
//  ADOH register bit map
//-------------------------------------------------------
volatile sbit ADO_16                    @ 0x10*8+0;
volatile sbit ADO_17                    @ 0x10*8+1;
volatile sbit ADO_18                    @ 0x10*8+2;
volatile sbit ADO_19                    @ 0x10*8+3;
volatile sbit ADO_20                    @ 0x10*8+4;
volatile sbit ADO_21                    @ 0x10*8+5;
volatile sbit ADO_22                    @ 0x10*8+6;
volatile sbit ADO_23                    @ 0x10*8+7;

//-------------------------------------------------------
//  ADOL register bit map
//-------------------------------------------------------
volatile sbit ADO_8                     @ 0x11*8+0;
volatile sbit ADO_9                     @ 0x11*8+1;
volatile sbit ADO_10                    @ 0x11*8+2;
volatile sbit ADO_11                    @ 0x11*8+3;
volatile sbit ADO_12                    @ 0x11*8+4;
volatile sbit ADO_13                    @ 0x11*8+5;
volatile sbit ADO_14                    @ 0x11*8+6;
volatile sbit ADO_15                    @ 0x11*8+7;

//-------------------------------------------------------
//  ADOLL register bit map
//-------------------------------------------------------
volatile sbit ADO_0                     @ 0x12*8+0;
volatile sbit ADO_1                     @ 0x12*8+1;
volatile sbit ADO_2                     @ 0x12*8+2;
volatile sbit ADO_3                     @ 0x12*8+3;
volatile sbit ADO_4                     @ 0x12*8+4;
volatile sbit ADO_5                     @ 0x12*8+5;
volatile sbit ADO_6                     @ 0x12*8+6;
volatile sbit ADO_7                     @ 0x12*8+7;

//-------------------------------------------------------
//  ADCON register bit map
//-------------------------------------------------------
volatile sbit ADM_0                     @ 0x13*8+0;
volatile sbit ADM_1                     @ 0x13*8+1;
volatile sbit ADM_2                     @ 0x13*8+2;
volatile sbit ADSC                      @ 0x13*8+3;
volatile sbit ADM_3                     @ 0x13*8+7;

//-------------------------------------------------------
//  MCK register bit map
//-------------------------------------------------------
volatile sbit M1_CK                     @ 0x14*8+1;
volatile sbit M2_CK                     @ 0x14*8+2;

//-------------------------------------------------------
//  PCK register bit map
//-------------------------------------------------------
volatile sbit S_beep_0                  @ 0x15*8+1;
volatile sbit S_beep_1                  @ 0x15*8+2;

//-------------------------------------------------------
//  NETA register bit map
//-------------------------------------------------------
volatile sbit CM_SEL                    @ 0x18*8+4;
volatile sbit SINL_0                    @ 0x18*8+6;
volatile sbit SINL_1                    @ 0x18*8+7;

//-------------------------------------------------------
//  NETC register bit map
//-------------------------------------------------------
volatile sbit ADEN                      @ 0x1A*8+1;
volatile sbit ADG_0                     @ 0x1A*8+2;
volatile sbit ADG_1                     @ 0x1A*8+3;
volatile sbit CHOPM_0                   @ 0x1A*8+6;
volatile sbit CHOPM_1                   @ 0x1A*8+7;

//-------------------------------------------------------
//  NETE register bit map
//-------------------------------------------------------
volatile sbit LB_RST_CON                @ 0x1C*8+0;
volatile sbit ENLB                      @ 0x1C*8+1;
volatile sbit SILB_0                    @ 0x1C*8+2;
volatile sbit SILB_1                    @ 0x1C*8+3;
volatile sbit SILB_2                    @ 0x1C*8+4;
volatile sbit LDOS_0                    @ 0x1C*8+6;
volatile sbit LDOS_1                    @ 0x1C*8+7;

//-------------------------------------------------------
//  NETF register bit map
//-------------------------------------------------------
volatile sbit BGID_0                    @ 0x1D*8+1;
volatile sbit BGID_1                    @ 0x1D*8+2;
volatile sbit LDOEN                     @ 0x1D*8+5;

//-------------------------------------------------------
//  SVD register bit map
//-------------------------------------------------------
volatile sbit LBOUT                     @ 0x1F*8+0;

//-------------------------------------------------------
//  PT1 register bit map
//-------------------------------------------------------
volatile sbit PT1_0                     @ 0x20*8+0;
volatile sbit PT1_1                     @ 0x20*8+1;
volatile sbit PT1_2                     @ 0x20*8+2;
volatile sbit PT1_3                     @ 0x20*8+3;

//-------------------------------------------------------
//  PT1EN register bit map
//-------------------------------------------------------
volatile sbit PT1EN_0                   @ 0x21*8+0;
volatile sbit PT1EN_1                   @ 0x21*8+1;
volatile sbit PT1EN_2                   @ 0x21*8+2;
volatile sbit PT1EN_3                   @ 0x21*8+3;

//-------------------------------------------------------
//  PT1PU register bit map
//-------------------------------------------------------
volatile sbit PT1PU_0                   @ 0x22*8+0;
volatile sbit PT1PU_1                   @ 0x22*8+1;
volatile sbit PT1PU_2                   @ 0x22*8+2;
volatile sbit PT1PU_3                   @ 0x22*8+3;

//-------------------------------------------------------
//  AIENB register bit map
//-------------------------------------------------------
volatile sbit AIENB1                    @ 0x23*8+3;
volatile sbit AIENB2                    @ 0x23*8+4;
volatile sbit AIENB3                    @ 0x23*8+7;

//-------------------------------------------------------
//  PT2 register bit map
//-------------------------------------------------------
volatile sbit PT2_0                     @ 0x24*8+0;
volatile sbit PT2_1                     @ 0x24*8+1;
volatile sbit PT2_2                     @ 0x24*8+2;
volatile sbit PT2_3                     @ 0x24*8+3;
volatile sbit PT2_4                     @ 0x24*8+4;
volatile sbit PT2_5                     @ 0x24*8+5;
volatile sbit PT2_6                     @ 0x24*8+6;
volatile sbit PT2_7                     @ 0x24*8+7;

//-------------------------------------------------------
//  PT2EN register bit map
//-------------------------------------------------------
volatile sbit PT2EN_0                   @ 0x25*8+0;
volatile sbit PT2EN_1                   @ 0x25*8+1;
volatile sbit PT2EN_2                   @ 0x25*8+2;
volatile sbit PT2EN_3                   @ 0x25*8+3;
volatile sbit PT2EN_4                   @ 0x25*8+4;
volatile sbit PT2EN_5                   @ 0x25*8+5;
volatile sbit PT2EN_6                   @ 0x25*8+6;
volatile sbit PT2EN_7                   @ 0x25*8+7;

//-------------------------------------------------------
//  PT2PU register bit map
//-------------------------------------------------------
volatile sbit PT2PU_0                   @ 0x26*8+0;
volatile sbit PT2PU_1                   @ 0x26*8+1;
volatile sbit PT2PU_2                   @ 0x26*8+2;
volatile sbit PT2PU_3                   @ 0x26*8+3;
volatile sbit PT2PU_4                   @ 0x26*8+4;
volatile sbit PT2PU_5                   @ 0x26*8+5;
volatile sbit PT2PU_6                   @ 0x26*8+6;
volatile sbit PT2PU_7                   @ 0x26*8+7;

//-------------------------------------------------------
//  PT4 register bit map
//-------------------------------------------------------
volatile sbit PT4_0                     @ 0x27*8+0;
volatile sbit PT4_1                     @ 0x27*8+1;
volatile sbit PT4_2                     @ 0x27*8+2;
volatile sbit PT4_3                     @ 0x27*8+3;
volatile sbit PT4_4                     @ 0x27*8+4;
volatile sbit PT4_5                     @ 0x27*8+5;
volatile sbit PT4_6                     @ 0x27*8+6;
volatile sbit PT4_7                     @ 0x27*8+7;

//-------------------------------------------------------
//  PT4EN register bit map
//-------------------------------------------------------
volatile sbit PT4EN_0                   @ 0x28*8+0;
volatile sbit PT4EN_1                   @ 0x28*8+1;
volatile sbit PT4EN_2                   @ 0x28*8+2;
volatile sbit PT4EN_3                   @ 0x28*8+3;
volatile sbit PT4EN_4                   @ 0x28*8+4;
volatile sbit PT4EN_5                   @ 0x28*8+5;
volatile sbit PT4EN_6                   @ 0x28*8+6;
volatile sbit PT4EN_7                   @ 0x28*8+7;

//-------------------------------------------------------
//  PT4PU register bit map
//-------------------------------------------------------
volatile sbit PT4PU_0                   @ 0x29*8+0;
volatile sbit PT4PU_1                   @ 0x29*8+1;
volatile sbit PT4PU_2                   @ 0x29*8+2;
volatile sbit PT4PU_3                   @ 0x29*8+3;
volatile sbit PT4PU_4                   @ 0x29*8+4;
volatile sbit PT4PU_5                   @ 0x29*8+5;
volatile sbit PT4PU_6                   @ 0x29*8+6;
volatile sbit PT4PU_7                   @ 0x29*8+7;

//-------------------------------------------------------
//  PT1CON register bit map
//-------------------------------------------------------
volatile sbit E0M_0                     @ 0x2D*8+0;
volatile sbit E0M_1                     @ 0x2D*8+1;
volatile sbit E1M_0                     @ 0x2D*8+2;
volatile sbit E1M_1                     @ 0x2D*8+3;
volatile sbit BZEN                      @ 0x2D*8+7;

//-------------------------------------------------------
//  PT2CON register bit map
//-------------------------------------------------------
volatile sbit PT2CON_0                  @ 0x2E*8+0;
volatile sbit PT2CON_1                  @ 0x2E*8+1;
volatile sbit PT2CON_2                  @ 0x2E*8+2;
volatile sbit PT2CON_3                  @ 0x2E*8+3;
volatile sbit PT2CON_4                  @ 0x2E*8+4;
volatile sbit PT2CON_5                  @ 0x2E*8+5;
volatile sbit PT2CON_6                  @ 0x2E*8+6;
volatile sbit PT2CON_7                  @ 0x2E*8+7;

//-------------------------------------------------------
//  PTINT register bit map
//-------------------------------------------------------
volatile sbit PTW0_0                    @ 0x2F*8+0;
volatile sbit PTW0_1                    @ 0x2F*8+1;
volatile sbit PTW0_2                    @ 0x2F*8+2;
volatile sbit PTW0_3                    @ 0x2F*8+3;
volatile sbit PTW1_0                    @ 0x2F*8+4;
volatile sbit PTW1_1                    @ 0x2F*8+5;
volatile sbit PTW1_2                    @ 0x2F*8+6;
volatile sbit PTW1_3                    @ 0x2F*8+7;

//-------------------------------------------------------
//  INTF2 register bit map
//-------------------------------------------------------
volatile sbit URRIF                     @ 0x32*8+0;
volatile sbit URTIF                     @ 0x32*8+1;
volatile sbit SPIIF                     @ 0x32*8+2;
volatile sbit RTCIF                     @ 0x32*8+3;

//-------------------------------------------------------
//  INTE2 register bit map
//-------------------------------------------------------
volatile sbit URRIE                     @ 0x33*8+0;
volatile sbit URTIE                     @ 0x33*8+1;
volatile sbit SPIIE                     @ 0x33*8+2;
volatile sbit RTCIE                     @ 0x33*8+3;

//-------------------------------------------------------
//  TM0CON register bit map
//-------------------------------------------------------
volatile sbit T0SEL                     @ 0x34*8+0;
volatile sbit T0RSTB                    @ 0x34*8+2;
volatile sbit T0RATE_0                  @ 0x34*8+4;
volatile sbit T0RATE_1                  @ 0x34*8+5;
volatile sbit T0RATE_2                  @ 0x34*8+6;
volatile sbit T0EN                      @ 0x34*8+7;

//-------------------------------------------------------
//  TM0IN register bit map
//-------------------------------------------------------
volatile sbit TM0IN_0                   @ 0x35*8+0;
volatile sbit TM0IN_1                   @ 0x35*8+1;
volatile sbit TM0IN_2                   @ 0x35*8+2;
volatile sbit TM0IN_3                   @ 0x35*8+3;
volatile sbit TM0IN_4                   @ 0x35*8+4;
volatile sbit TM0IN_5                   @ 0x35*8+5;
volatile sbit TM0IN_6                   @ 0x35*8+6;
volatile sbit TM0IN_7                   @ 0x35*8+7;

//-------------------------------------------------------
//  TM0CNT register bit map
//-------------------------------------------------------
volatile sbit TM0CNT_0                  @ 0x36*8+0;
volatile sbit TM0CNT_1                  @ 0x36*8+1;
volatile sbit TM0CNT_2                  @ 0x36*8+2;
volatile sbit TM0CNT_3                  @ 0x36*8+3;
volatile sbit TM0CNT_4                  @ 0x36*8+4;
volatile sbit TM0CNT_5                  @ 0x36*8+5;
volatile sbit TM0CNT_6                  @ 0x36*8+6;
volatile sbit TM0CNT_7                  @ 0x36*8+7;

//-------------------------------------------------------
//  TM1CON register bit map
//-------------------------------------------------------
volatile sbit PWM1OUT                   @ 0x37*8+0;
volatile sbit T1OUT                     @ 0x37*8+1;
volatile sbit T1RSTB                    @ 0x37*8+2;
volatile sbit T1CKS                     @ 0x37*8+3;
volatile sbit T1RATE_0                  @ 0x37*8+4;
volatile sbit T1RATE_1                  @ 0x37*8+5;
volatile sbit T1RATE_2                  @ 0x37*8+6;
volatile sbit T1EN                      @ 0x37*8+7;

//-------------------------------------------------------
//  TM1IN register bit map
//-------------------------------------------------------
volatile sbit TM1IN_0                   @ 0x38*8+0;
volatile sbit TM1IN_1                   @ 0x38*8+1;
volatile sbit TM1IN_2                   @ 0x38*8+2;
volatile sbit TM1IN_3                   @ 0x38*8+3;
volatile sbit TM1IN_4                   @ 0x38*8+4;
volatile sbit TM1IN_5                   @ 0x38*8+5;
volatile sbit TM1IN_6                   @ 0x38*8+6;
volatile sbit TM1IN_7                   @ 0x38*8+7;

//-------------------------------------------------------
//  TM1CNT register bit map
//-------------------------------------------------------
volatile sbit TM1CNT_0                  @ 0x39*8+0;
volatile sbit TM1CNT_1                  @ 0x39*8+1;
volatile sbit TM1CNT_2                  @ 0x39*8+2;
volatile sbit TM1CNT_3                  @ 0x39*8+3;
volatile sbit TM1CNT_4                  @ 0x39*8+4;
volatile sbit TM1CNT_5                  @ 0x39*8+5;
volatile sbit TM1CNT_6                  @ 0x39*8+6;
volatile sbit TM1CNT_7                  @ 0x39*8+7;

//-------------------------------------------------------
//  TM1R register bit map
//-------------------------------------------------------
volatile sbit TM1R_0                    @ 0x3A*8+0;
volatile sbit TM1R_1                    @ 0x3A*8+1;
volatile sbit TM1R_2                    @ 0x3A*8+2;
volatile sbit TM1R_3                    @ 0x3A*8+3;
volatile sbit TM1R_4                    @ 0x3A*8+4;
volatile sbit TM1R_5                    @ 0x3A*8+5;
volatile sbit TM1R_6                    @ 0x3A*8+6;
volatile sbit TM1R_7                    @ 0x3A*8+7;

//-------------------------------------------------------
//  LED1 register bit map
//-------------------------------------------------------
volatile sbit LED1_0                    @ 0x3B*8+0;
volatile sbit LED1_1                    @ 0x3B*8+1;
volatile sbit LED1_2                    @ 0x3B*8+2;
volatile sbit LED1_3                    @ 0x3B*8+3;
volatile sbit LED1_4                    @ 0x3B*8+4;
volatile sbit LED1_5                    @ 0x3B*8+5;
volatile sbit LED1_6                    @ 0x3B*8+6;
volatile sbit LED1_7                    @ 0x3B*8+7;

//-------------------------------------------------------
//  LED2 register bit map
//-------------------------------------------------------
volatile sbit LED2_0                    @ 0x3C*8+0;
volatile sbit LED2_1                    @ 0x3C*8+1;
volatile sbit LED2_2                    @ 0x3C*8+2;
volatile sbit LED2_3                    @ 0x3C*8+3;
volatile sbit LED2_4                    @ 0x3C*8+4;
volatile sbit LED2_5                    @ 0x3C*8+5;
volatile sbit LED2_6                    @ 0x3C*8+6;
volatile sbit LED2_7                    @ 0x3C*8+7;

//-------------------------------------------------------
//  LED3 register bit map
//-------------------------------------------------------
volatile sbit LED3_0                    @ 0x3D*8+0;
volatile sbit LED3_1                    @ 0x3D*8+1;
volatile sbit LED3_2                    @ 0x3D*8+2;
volatile sbit LED3_3                    @ 0x3D*8+3;
volatile sbit LED3_4                    @ 0x3D*8+4;
volatile sbit LED3_5                    @ 0x3D*8+5;
volatile sbit LED3_6                    @ 0x3D*8+6;
volatile sbit LED3_7                    @ 0x3D*8+7;

//-------------------------------------------------------
//  LED4 register bit map
//-------------------------------------------------------
volatile sbit LED4_0                    @ 0x3E*8+0;
volatile sbit LED4_1                    @ 0x3E*8+1;
volatile sbit LED4_2                    @ 0x3E*8+2;
volatile sbit LED4_3                    @ 0x3E*8+3;
volatile sbit LED4_4                    @ 0x3E*8+4;
volatile sbit LED4_5                    @ 0x3E*8+5;
volatile sbit LED4_6                    @ 0x3E*8+6;
volatile sbit LED4_7                    @ 0x3E*8+7;

//-------------------------------------------------------
//  LED5 register bit map
//-------------------------------------------------------
volatile sbit LED5_0                    @ 0x3F*8+0;
volatile sbit LED5_1                    @ 0x3F*8+1;
volatile sbit LED5_2                    @ 0x3F*8+2;
volatile sbit LED5_3                    @ 0x3F*8+3;
volatile sbit LED5_4                    @ 0x3F*8+4;
volatile sbit LED5_5                    @ 0x3F*8+5;
volatile sbit LED5_6                    @ 0x3F*8+6;
volatile sbit LED5_7                    @ 0x3F*8+7;

//-------------------------------------------------------
//  LED6 register bit map
//-------------------------------------------------------
volatile sbit LED6_0                    @ 0x40*8+0;
volatile sbit LED6_1                    @ 0x40*8+1;
volatile sbit LED6_2                    @ 0x40*8+2;
volatile sbit LED6_3                    @ 0x40*8+3;
volatile sbit LED6_4                    @ 0x40*8+4;
volatile sbit LED6_5                    @ 0x40*8+5;
volatile sbit LED6_6                    @ 0x40*8+6;
volatile sbit LED6_7                    @ 0x40*8+7;

//-------------------------------------------------------
//  LED7 register bit map
//-------------------------------------------------------
volatile sbit LED7_0                    @ 0x41*8+0;
volatile sbit LED7_1                    @ 0x41*8+1;
volatile sbit LED7_2                    @ 0x41*8+2;
volatile sbit LED7_3                    @ 0x41*8+3;
volatile sbit LED7_4                    @ 0x41*8+4;
volatile sbit LED7_5                    @ 0x41*8+5;
volatile sbit LED7_6                    @ 0x41*8+6;
volatile sbit LED7_7                    @ 0x41*8+7;

//-------------------------------------------------------
//  LEDCON1 register bit map
//-------------------------------------------------------
volatile sbit LED_PMODE                 @ 0x42*8+0;
volatile sbit LEDCLKS_0                 @ 0x42*8+1;
volatile sbit LEDCLKS_1                 @ 0x42*8+2;
volatile sbit LCD_DUTY_0                @ 0x42*8+3;
volatile sbit LCD_DUTY_1                @ 0x42*8+4;
volatile sbit LED_CURRENT_0                @ 0x42*8+5;
volatile sbit LED_CURRENT_1                @ 0x42*8+6;
volatile sbit LED_CURRENT_2                @ 0x42*8+7;

//-------------------------------------------------------
//  LEDCON2 register bit map
//-------------------------------------------------------
volatile sbit LEDEN                     @ 0x43*8+0;

//-------------------------------------------------------
//  CHPCON register bit map
//-------------------------------------------------------
volatile sbit CHPEN                     @ 0x44*8+0;
volatile sbit CHPCLKS_0                 @ 0x44*8+1;
volatile sbit CHPCLKS_1                 @ 0x44*8+2;
volatile sbit CHPVS                     @ 0x44*8+4;

//-------------------------------------------------------
//  AD2OH register bit map
//-------------------------------------------------------
volatile sbit AD2O_8                    @ 0x48*8+0;
volatile sbit AD2O_9                    @ 0x48*8+1;
volatile sbit AD2EN                     @ 0x48*8+7;

//-------------------------------------------------------
//  AD2OL register bit map
//-------------------------------------------------------
volatile sbit AD2O_0                    @ 0x49*8+0;
volatile sbit AD2O_1                    @ 0x49*8+1;
volatile sbit AD2O_2                    @ 0x49*8+2;
volatile sbit AD2O_3                    @ 0x49*8+3;
volatile sbit AD2O_4                    @ 0x49*8+4;
volatile sbit AD2O_5                    @ 0x49*8+5;
volatile sbit AD2O_6                    @ 0x49*8+6;
volatile sbit AD2O_7                    @ 0x49*8+7;

//-------------------------------------------------------
//  FILCON register bit map
//-------------------------------------------------------
volatile sbit FIL1_EN                   @ 0x4A*8+0;
volatile sbit FIL2_EN                   @ 0x4A*8+4;

//-------------------------------------------------------
//  DTHREH register bit map
//-------------------------------------------------------
volatile sbit DATA_THRE_8                @ 0x4B*8+0;
volatile sbit DATA_THRE_9                @ 0x4B*8+1;
volatile sbit DATA_THRE_10                @ 0x4B*8+2;
volatile sbit DATA_THRE_11                @ 0x4B*8+3;
volatile sbit DATA_THRE_12                @ 0x4B*8+4;
volatile sbit DATA_THRE_13                @ 0x4B*8+5;
volatile sbit DATA_THRE_14                @ 0x4B*8+6;
volatile sbit DATA_THRE_15                @ 0x4B*8+7;

//-------------------------------------------------------
//  DTHREL register bit map
//-------------------------------------------------------
volatile sbit DATA_THRE_0                @ 0x4C*8+0;
volatile sbit DATA_THRE_1                @ 0x4C*8+1;
volatile sbit DATA_THRE_2                @ 0x4C*8+2;
volatile sbit DATA_THRE_3                @ 0x4C*8+3;
volatile sbit DATA_THRE_4                @ 0x4C*8+4;
volatile sbit DATA_THRE_5                @ 0x4C*8+5;
volatile sbit DATA_THRE_6                @ 0x4C*8+6;
volatile sbit DATA_THRE_7                @ 0x4C*8+7;

//-------------------------------------------------------
//  NTHRE register bit map
//-------------------------------------------------------
volatile sbit NTHRE_0                   @ 0x4D*8+0;
volatile sbit NTHRE_1                   @ 0x4D*8+1;
volatile sbit NTHRE_2                   @ 0x4D*8+2;
volatile sbit NTHRE_3                   @ 0x4D*8+3;
volatile sbit NTHRE_4                   @ 0x4D*8+4;
volatile sbit NTHRE_5                   @ 0x4D*8+5;

//-------------------------------------------------------
//  NCON register bit map
//-------------------------------------------------------
volatile sbit NSEL_0                    @ 0x4E*8+0;
volatile sbit NSEL_1                    @ 0x4E*8+1;
volatile sbit NSEL_2                    @ 0x4E*8+2;

//-------------------------------------------------------
//  SPICFG register bit map
//-------------------------------------------------------
volatile sbit SPIRST                    @ 0x50*8+0;
volatile sbit SPIBSY                    @ 0x50*8+1;
volatile sbit WIREMOD                   @ 0x50*8+2;
volatile sbit MULMST                    @ 0x50*8+3;
volatile sbit CKPOL                     @ 0x50*8+4;
volatile sbit CKPHA                     @ 0x50*8+5;
volatile sbit MSTEN                     @ 0x50*8+6;
volatile sbit SPIEN                     @ 0x50*8+7;

//-------------------------------------------------------
//  SPICN register bit map
//-------------------------------------------------------
volatile sbit MODCOL                    @ 0x51*8+5;
volatile sbit WCOL                      @ 0x51*8+6;
volatile sbit SLVSEL                    @ 0x51*8+7;

//-------------------------------------------------------
//  SPICKR register bit map
//-------------------------------------------------------
volatile sbit SCR_0                     @ 0x52*8+0;
volatile sbit SCR_1                     @ 0x52*8+1;
volatile sbit SCR_2                     @ 0x52*8+2;
volatile sbit SCR_3                     @ 0x52*8+3;
volatile sbit SCR_4                     @ 0x52*8+4;
volatile sbit SCR_5                     @ 0x52*8+5;
volatile sbit SCR_6                     @ 0x52*8+6;
volatile sbit SCR_7                     @ 0x52*8+7;

//-------------------------------------------------------
//  SPIDAT register bit map
//-------------------------------------------------------
volatile sbit SPIDAT_0                  @ 0x53*8+0;
volatile sbit SPIDAT_1                  @ 0x53*8+1;
volatile sbit SPIDAT_2                  @ 0x53*8+2;
volatile sbit SPIDAT_3                  @ 0x53*8+3;
volatile sbit SPIDAT_4                  @ 0x53*8+4;
volatile sbit SPIDAT_5                  @ 0x53*8+5;
volatile sbit SPIDAT_6                  @ 0x53*8+6;
volatile sbit SPIDAT_7                  @ 0x53*8+7;

//-------------------------------------------------------
//  TEMPC register bit map
//-------------------------------------------------------
volatile sbit TEMPC_0                   @ 0x59*8+0;
volatile sbit TEMPC_1                   @ 0x59*8+1;
volatile sbit TEMPC_2                   @ 0x59*8+2;
volatile sbit TEMPC_3                   @ 0x59*8+3;
volatile sbit TEMPC_4                   @ 0x59*8+4;
volatile sbit TEMPC_5                   @ 0x59*8+5;
volatile sbit TEMPC_6                   @ 0x59*8+6;
volatile sbit TEMPC_7                   @ 0x59*8+7;

//-------------------------------------------------------
//  RTCCON register bit map
//-------------------------------------------------------
volatile sbit RTCEN                     @ 0x60*8+3;
volatile sbit RTCCON_24hr_12hr                @ 0x60*8+5;
volatile sbit LIR                       @ 0x60*8+7;

//-------------------------------------------------------
//  RTCAER register bit map
//-------------------------------------------------------
volatile sbit AER_0                     @ 0x61*8+0;
volatile sbit AER_1                     @ 0x61*8+1;
volatile sbit AER_2                     @ 0x61*8+2;
volatile sbit AER_3                     @ 0x61*8+3;
volatile sbit AER_4                     @ 0x61*8+4;
volatile sbit AER_5                     @ 0x61*8+5;
volatile sbit AER_6                     @ 0x61*8+6;
volatile sbit AER_7                     @ 0x61*8+7;

//-------------------------------------------------------
//  RTCYEAR register bit map
//-------------------------------------------------------
volatile sbit RTCYEAR_1YEAR_0                @ 0x62*8+0;
volatile sbit RTCYEAR_1YEAR_1                @ 0x62*8+1;
volatile sbit RTCYEAR_1YEAR_2                @ 0x62*8+2;
volatile sbit RTCYEAR_1YEAR_3                @ 0x62*8+3;
volatile sbit RTCYEAR_10YEAR_4                @ 0x62*8+4;
volatile sbit RTCYEAR_10YEAR_5                @ 0x62*8+5;
volatile sbit RTCYEAR_10YEAR_6                @ 0x62*8+6;
volatile sbit RTCYEAR_10YEAR_7                @ 0x62*8+7;

//-------------------------------------------------------
//  RTCMON register bit map
//-------------------------------------------------------
volatile sbit RTCMON_1MON_0                @ 0x63*8+0;
volatile sbit RTCMON_1MON_1                @ 0x63*8+1;
volatile sbit RTCMON_1MON_2                @ 0x63*8+2;
volatile sbit RTCMON_1MON_3                @ 0x63*8+3;
volatile sbit RTCMON_10MON                @ 0x63*8+4;

//-------------------------------------------------------
//  RTCDAY register bit map
//-------------------------------------------------------
volatile sbit RTCDAY_1DAT_0                @ 0x64*8+0;
volatile sbit RTCDAY_1DAT_1                @ 0x64*8+1;
volatile sbit RTCDAY_1DAT_2                @ 0x64*8+2;
volatile sbit RTCDAY_1DAT_3                @ 0x64*8+3;
volatile sbit RTCDAY_10DAY_0                @ 0x64*8+4;
volatile sbit RTCDAY_10DAY_1                @ 0x64*8+5;

//-------------------------------------------------------
//  RTCHOUR register bit map
//-------------------------------------------------------
volatile sbit RTCHOUR_1HOUR_0                @ 0x65*8+0;
volatile sbit RTCHOUR_1HOUR_1                @ 0x65*8+1;
volatile sbit RTCHOUR_1HOUR_2                @ 0x65*8+2;
volatile sbit RTCHOUR_1HOUR_3                @ 0x65*8+3;
volatile sbit RTCHOUR_10HOUR10_0                @ 0x65*8+4;
volatile sbit RTCHOUR_10HOUR10_1                @ 0x65*8+5;

//-------------------------------------------------------
//  RTCMIN register bit map
//-------------------------------------------------------
volatile sbit RTCMIN_1MIN_0                @ 0x66*8+0;
volatile sbit RTCMIN_1MIN_1                @ 0x66*8+1;
volatile sbit RTCMIN_1MIN_2                @ 0x66*8+2;
volatile sbit RTCMIN_1MIN_3                @ 0x66*8+3;
volatile sbit RTCMIN_10MIN_0                @ 0x66*8+4;
volatile sbit RTCMIN_10MIN_1                @ 0x66*8+5;
volatile sbit RTCMIN_10MIN_2                @ 0x66*8+6;

//-------------------------------------------------------
//  RTCSEC register bit map
//-------------------------------------------------------
volatile sbit RTCSEC_1SEC_0                @ 0x67*8+0;
volatile sbit RTCSEC_1SEC_1                @ 0x67*8+1;
volatile sbit RTCSEC_1SEC_2                @ 0x67*8+2;
volatile sbit RTCSEC_1SEC_3                @ 0x67*8+3;
volatile sbit RTCSEC_10SEC_0                @ 0x67*8+4;
volatile sbit RTCSEC_10SEC_1                @ 0x67*8+5;
volatile sbit RTCSEC_10SEC_2                @ 0x67*8+6;

//-------------------------------------------------------
//  RTCDWR register bit map
//-------------------------------------------------------
volatile sbit DWR_0                     @ 0x68*8+0;
volatile sbit DWR_1                     @ 0x68*8+1;
volatile sbit DWR_2                     @ 0x68*8+2;

//-------------------------------------------------------
//  INTEGER register bit map
//-------------------------------------------------------
volatile sbit INTEGER_0                 @ 0x69*8+0;
volatile sbit INTEGER_1                 @ 0x69*8+1;
volatile sbit INTEGER_2                 @ 0x69*8+2;
volatile sbit INTEGER_3                 @ 0x69*8+3;

//-------------------------------------------------------
//  FRACTION register bit map
//-------------------------------------------------------
volatile sbit FRACTION_0                @ 0x6A*8+0;
volatile sbit FRACTION_1                @ 0x6A*8+1;
volatile sbit FRACTION_2                @ 0x6A*8+2;
volatile sbit FRACTION_3                @ 0x6A*8+3;
volatile sbit FRACTION_4                @ 0x6A*8+4;
volatile sbit FRACTION_5                @ 0x6A*8+5;

//-------------------------------------------------------
//  WDT_C register bit map
//-------------------------------------------------------
volatile sbit WDT_C_0                   @ 0x6D*8+0;
volatile sbit WDT_C_1                   @ 0x6D*8+1;
volatile sbit WDT_C_2                   @ 0x6D*8+2;

//-------------------------------------------------------
//  IOSC_C register bit map
//-------------------------------------------------------
volatile sbit IOSC_C_0                  @ 0x6E*8+0;
volatile sbit IOSC_C_1                  @ 0x6E*8+1;
volatile sbit IOSC_C_2                  @ 0x6E*8+2;
volatile sbit IOSC_C_3                  @ 0x6E*8+3;
volatile sbit IOSC_C_4                  @ 0x6E*8+4;
volatile sbit IOSC_C_5                  @ 0x6E*8+5;
volatile sbit IOSC_C_6                  @ 0x6E*8+6;
volatile sbit IOSC_C_7                  @ 0x6E*8+7;

//-------------------------------------------------------
//  VS_C register bit map
//-------------------------------------------------------
volatile sbit VS_C_0                    @ 0x6F*8+0;
volatile sbit VS_C_1                    @ 0x6F*8+1;
volatile sbit VS_C_2                    @ 0x6F*8+2;
volatile sbit VS_C_3                    @ 0x6F*8+3;

//-------------------------------------------------------
//  TMODE register bit map
//-------------------------------------------------------
volatile sbit TMOD_0                    @ 0x71*8+0;
volatile sbit TMOD_1                    @ 0x71*8+1;
volatile sbit sim_rst                   @ 0x71*8+7;

//-------------------------------------------------------
//  SCON1 register bit map
//-------------------------------------------------------
volatile sbit UARTEN                    @ 0x7A*8+0;
volatile sbit UART_SEL                  @ 0x7A*8+1;
volatile sbit RB8                       @ 0x7A*8+2;
volatile sbit TB8                       @ 0x7A*8+3;
volatile sbit REN                       @ 0x7A*8+4;
volatile sbit SM2                       @ 0x7A*8+5;
volatile sbit SM1                       @ 0x7A*8+6;
volatile sbit SM0                       @ 0x7A*8+7;

//-------------------------------------------------------
//  SCON2 register bit map
//-------------------------------------------------------
volatile sbit UARTCLKS                  @ 0x7B*8+6;
volatile sbit SMOD                      @ 0x7B*8+7;

//-------------------------------------------------------
//  LEDTEST1 register bit map
//-------------------------------------------------------
volatile sbit LEDTEST1_0                @ 0x7D*8+0;
volatile sbit LEDTEST1_1                @ 0x7D*8+1;
volatile sbit LEDTEST1_2                @ 0x7D*8+2;
volatile sbit LEDTEST1_3                @ 0x7D*8+3;
volatile sbit LEDTEST1_4                @ 0x7D*8+4;
volatile sbit LEDTEST1_5                @ 0x7D*8+5;
volatile sbit LEDTEST1_6                @ 0x7D*8+6;
volatile sbit LEDTEST1_7                @ 0x7D*8+7;

//-------------------------------------------------------
//  METCH register bit map
//-------------------------------------------------------
volatile sbit METCH_0                   @ 0x7E*8+0;
volatile sbit METCH_1                   @ 0x7E*8+1;
volatile sbit METCH_2                   @ 0x7E*8+2;
volatile sbit METCH_3                   @ 0x7E*8+3;
volatile sbit METCH_4                   @ 0x7E*8+4;
volatile sbit METCH_5                   @ 0x7E*8+5;
volatile sbit METCH_6                   @ 0x7E*8+6;
volatile sbit METCH_7                   @ 0x7E*8+7;

//-------------------------------------------------------
//  LEDTEST2 register bit map
//-------------------------------------------------------
volatile sbit LEDTEST2_0                @ 0x7F*8+0;
volatile sbit LEDTEST2_1                @ 0x7F*8+1;
volatile sbit LEDTEST2_2                @ 0x7F*8+2;
volatile sbit LEDTEST2_3                @ 0x7F*8+3;
volatile sbit LEDTEST2_4                @ 0x7F*8+4;
volatile sbit LEDTEST2_5                @ 0x7F*8+5;
volatile sbit LEDTEST2_6                @ 0x7F*8+6;
volatile sbit LEDTEST2_7                @ 0x7F*8+7;

