﻿#include "CSU18MB86.h"
#include "CS_18MB86_Init.h"

unsigned char xWork;


/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	
*******************************************************************************/
void IO_Init(void)
{
	AIENB1 = 1; //0 = PT1.3为模拟口，1 = PT1.3为数字口
	AIENB2 = 1; //0 = PT2.2为模拟口，1 = PT2.2为数字口
	AIENB3 = 1; //0 = PT4.0/1为模拟口，1 = PT4.0/1为数字口
	
	PT1EN  = 0b00001111;		//0 = input,1 = ouput
	PT1PU  = 0b00000000;		//0 = 无上拉,1 = 上拉
	PT1    = 0b00000000;
	
	PT2EN  = 0b11111111;		//0 = input,1 = ouput
	PT2PU  = 0b00000000;		//0 = 无上拉,1 = 上拉
	PT2    = 0b00000000;
	
	PT4EN  = 0b00000111;		//0 = input,1 = ouput
	PT4PU  = 0b00000000;		//0 = 无上拉,1 = 上拉
	PT4    = 0b00000000;
	
	//复用功能配置
	PT1CON = 0b00000000;		//
	                            //bit7: BZEN
	                            //0 = 使能蜂鸣器功能，PT1.2为蜂鸣器输出口
	                            //1 = 不使能蜂鸣器功能，PT1.2为普通IO
	                            
	                            //bit3-2: E1M[1:0] 
	                            //11 = 外部中断1在状态改变时触发
	                            //10 = 外部中断1在状态改变时触发
	                            //01 = 外部中断1上升沿触发
	                            //00 = 外部中断1下降沿触发
	                            
	                            //bit1-0: E0M[1:0] 
	                            //11 = 外部中断0在状态改变时触发
	                            //10 = 外部中断0在状态改变时触发
	                            //01 = 外部中断0上升沿触发
	                            //00 = 外部中断0下降沿触发
	                            
	PT2CON = 0b00000000;		//PT2模式控制，常规使用配置为0x00 即可。
	
	PTINT  = 0b00000000;        //
	                            //bit7: 
	                            //0 = 禁止PT4.1外部中断1
	                            //1 = 使能PT4.1外部中断1
	                            
	                            //bit6: 
	                            //0 = 禁止PT2.1外部中断1
	                            //1 = 使能PT2.1外部中断1
	                            
	                            //bit5: 
	                            //0 = 禁止PT1.3外部中断1
	                            //1 = 使能PT1.3外部中断1
	                            
	                            //bit4: 
	                            //0 = 禁止PT1.1外部中断1
	                            //1 = 使能PT1.1外部中断1
	                            
	                            //bit3: 保留
	                            
	                            //bit2: 
	                            //0 = 禁止PT2.0外部中断0
	                            //1 = 使能PT2.0外部中断0
	                            
	                            //bit1: 
	                            //0 = 禁止PT1.2外部中断0
	                            //1 = 使能PT1.2外部中断0
	                            
	                            //bit0: 
	                            //0 = 禁止PT1.0外部中断0
	                            //1 = 使能PT1.0外部中断0
	                            
}


/*******************************************************************************
* Input      : baud 可选的值有9600或者115200    	                                                           
* Output     :     	                                
* Description: 该IC只支持9600和115200两种波特率
               修改波特率需要修改时钟频率，在代码选项中修改。
               9600，选择16M
               115200，选择14.7M
*******************************************************************************/
void Uart_Init(unsigned long baud)
{
	SCON1 = 0b01010001;
	if(baud == 115200)
	{
		SMOD = 1;
		UARTCLKS = 1;
	}
	URTIE = 0;	//0 = 禁止TX中断，1 = 使能TX中断
	URRIE = 1;	//0 = 禁止RX中断，1 = 使能RX中断
	GIE   = 1;  //0 = 禁止全局中断，1 = 使能全局中断	
}

/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	
*******************************************************************************/
void ADC24bit_Init(void)
{
	struct ADC24bit ADC24bitSet;
	//在这里修改配置
	ADC24bitSet.SampleRate = 250;	//采样速率，可选 250,500 (KHz)
	ADC24bitSet.OutputRate = 30;	//输出速率，可选 30,61,122,244,488,976,1953,3906 (Hz)
	ADC24bitSet.PGA = 1;            //放大倍数，可选 1,16,64,128         
	ADC24bitSet.VS = 300;			//参考电压，可选 235,245,280,300  (235表示2.35V 以此类推)
	ADC24bitSet.TEMPC = 0;			//温度补偿，可选 0,45,90,130,-45,-90,-130 (ppm)
	ADC24bitSet.Enable = 1;         //使能，可选 0,1      
	
	
	NETA = 0x10;
	//
	switch	(ADC24bitSet.SampleRate)
	{
	case 500:
		ADCON |= ADC24BIT_SAMPLE_RATE_250KHz;
		break;
	default:	
	case 250:
		ADCON |= ADC24BIT_SAMPLE_RATE_500KHz;
		break;		
	}
	//
	switch	(ADC24bitSet.OutputRate)
	{
	case 30:
		ADCON |= ADC24BIT_OUTPUT_RATE_30Hz;
		break;
	case 61:
		ADCON |= ADC24BIT_OUTPUT_RATE_61Hz;
		break;
	case 122:
		ADCON |= ADC24BIT_OUTPUT_RATE_122Hz;
		break;
	case 244:
		ADCON |= ADC24BIT_OUTPUT_RATE_244Hz;
		break;
	case 488:
		ADCON |= ADC24BIT_OUTPUT_RATE_488Hz;
		break;
	case 976:
		ADCON |= ADC24BIT_OUTPUT_RATE_976Hz;
		break;
	case 1953:
		ADCON |= ADC24BIT_OUTPUT_RATE_1953Hz;
		break;
	default:	
	case 3906:
		ADCON |= ADC24BIT_OUTPUT_RATE_3906Hz;
		break;		
	}
	//
	switch	(ADC24bitSet.PGA)
	{
	case 16:
		NETC |= ADC24BIT_PGA_16;
		break;
	case 64:
		NETC |= ADC24BIT_PGA_64;
		break;
	case 128:
		NETC |= ADC24BIT_PGA_128;
		break;		
	default:	
	case 1:
		NETC |= ADC24BIT_PGA_1;
		break;		
	}
	//
	switch	(ADC24bitSet.VS)
	{
	case 235:
		NETE |= ADC24BIT_VS_2_35V;
		LDOEN = 1;
		break;
	case 245:
		NETE |= ADC24BIT_VS_2_45V;
		LDOEN = 1;
		break;
	case 280:
		NETE |= ADC24BIT_VS_2_8V;
		LDOEN = 1;
		break;	
	default:	
	case 300:
		NETE |= ADC24BIT_VS_3V;
		LDOEN = 1;
		break;		
	}
	//
	switch	(ADC24bitSet.TEMPC)
	{
	case 45:
		TEMPC |= ADC24BIT_TEMPC_45PPM;
		break;
	case 90:
		TEMPC |= ADC24BIT_TEMPC_90PPM;
		break;
	case 130:
		TEMPC |= ADC24BIT_TEMPC_130PPM;
		break;
	case -45:
		TEMPC |= ADC24BIT_TEMPC_NEG_45PPM;
		break;
	case -90:
		TEMPC |= ADC24BIT_TEMPC_NEG_90PPM;
		break;	
	case -130:
		TEMPC |= ADC24BIT_TEMPC_NEG_130PPM;
		break;	
	default:	
	case 0:
		TEMPC |= ADC24BIT_TEMPC_0PPM;
		break;		
	}
	
	//
	if(ADC24bitSet.Enable == 1)
	{
		ADEN = 1;
		ADIE = 1;
	}
	else
	{
		ADEN = 0;
		ADIE = 0;
		LDOEN = 0;
	}
}

/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	
*******************************************************************************/
void ADC10bit_Init(void)
{

}

/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	8bit定时器
*******************************************************************************/
void Timer0_Init(void)
{
	struct TIMER0 TIMER0_SET;
	//在这里修改配置
	TIMER0_SET.TM0CLK_SRC = 0;		//时钟源选择，0 = CPUCLK,1 = 内部3K WDT时钟(需要打开WDT时钟)
	TIMER0_SET.TM0CLK_DIV = 128;		//分频选择，可选 0,2,4,8,16,32,64,128
	TIMER0_SET.TM0IN = 155;			//溢出时间，范围1-255，溢出时间 = (TM0IN+1)/TM0CLK，TM0CLK = TM0CLK_SRC/TM0CLK_DIV
	TIMER0_SET.Enable = 1;			//定时器，0 = 不使能，1 = 使能
	
	
	TM0IN = TIMER0_SET.TM0IN;
	
	if(TIMER0_SET.TM0CLK_SRC == 1)
	{
		T0SEL = 1;	
	}
	
	switch (TIMER0_SET.TM0CLK_DIV)
	{
	case 2:
		TM0CON |= 0b00010000;
		break;
	case 4:
		TM0CON |= 0b00100000;
		break;	
	case 8:
		TM0CON |= 0b00110000;
		break;
	case 16:
		TM0CON |= 0b01000000;
		break;
	case 32:
		TM0CON |= 0b01010000;
		break;
	case 64:
		TM0CON |= 0b01100000;
		break;
	case 128:
		TM0CON |= 0b01110000;
		break;	
	default:
	case 0:
		TM0CON |= 0x00;
		break;
	}
	
	if(TIMER0_SET.Enable == 1)
	{
		T0EN = 1;
		TM0IE = 1;
		GIE  = 1;
	}
	else
	{
		T0EN = 0;
		TM0IE = 0;
	}
	
}

/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	8bit定时器，比TIMER0多PWM功能
*******************************************************************************/
void Timer1_Init(void)
{
	struct TIMER1 TIMER1_SET;
	//在这里修改配置
	TIMER1_SET.PWM_HIGH = 100;		//高电平时间，范围 0 ~ TIMER1_SET.TM1IN
	TIMER1_SET.TM1IN = 199;			//溢出时间，范围1-255，溢出时间 = (TM0IN+1)/TM0CLK，TM0CLK = TM0CLK_SRC/TM0CLK_DIV
	TIMER1_SET.PWM_Enable = 1;      //PWM，0 = 不使能，1 = 使能  （PWM在PT4.1输出，仅SSOP24封装有）
	TIMER1_SET.Enable = 1;			//定时器，0 = 不使能，1 = 使能
	
	
	TM1IN = TIMER1_SET.TM1IN;
	TM1R = TIMER1_SET.PWM_HIGH;	
	switch (TIMER1_SET.TM1CLK_DIV)
	{
	case 2:
		TM1CON |= 0b00010000;
		break;
	case 4:
		TM1CON |= 0b00100000;
		break;	
	case 8:
		TM1CON |= 0b00110000;
		break;
	case 16:
		TM1CON |= 0b01000000;
		break;
	case 32:
		TM1CON |= 0b01010000;
		break;
	case 64:
		TM1CON |= 0b01100000;
		break;
	case 128:
		TM1CON |= 0b01110000;
		break;	
	default:
	case 0:
		TM1CON |= 0x00;
		break;
	}
	
	if(TIMER1_SET.Enable == 1)
	{
		T1EN = 1;
		TM1IE = 1;
		GIE  = 1;
	}
	else
	{
		T1EN = 0;
		TM1IE = 0;
	}
	
	if(TIMER1_SET.PWM_Enable == 1)
	{
		T1OUT = 0;
		PWM1OUT = 1;
				
	}
	else
	{
		T1OUT = 0;
		PWM1OUT = 0;
	}
}


/*******************************************************************************
* Input      : E2_Adress -- E2PROM地址，取值0-127
               *p        -- 待写数据地址
               nByte     -- 写数据个数，取值1-127
* Output     :     	                                
* Description: 
               128Byte E2PROM，1万次write寿命。
               写过程会关闭全局中断。
*******************************************************************************/
void MB86_E2PROM_Write(unsigned char E2_Adress,unsigned char *p,unsigned char nByte)
{
	unsigned char xEADRL;
	unsigned char i;
	
	xEADRL = E2_Adress;
	if(xEADRL>127)
	{
		return;
	}
	
	GIE = 0;
	WDTCON = 0b10001011;	//2s
	for(i=0; i<nByte; i++)
	{
		asm	("CLRWDT");
		EOPEN = 0x96;	//解锁
		EOPEN = 0x69;
		EOPEN = 0x5A;
		
		EADRH = 0x20;
		EADRL = xEADRL;		
		EDAT  = 0;
		xWork = *p++;
		
		EOPEN = 0x96;	//解锁
		EOPEN = 0x69;
		EOPEN = 0x5A;
				
		asm ("movfw _xWork");
		asm ("TBLP 130");
		xEADRL++;
		if(xEADRL > 127)
		{
			return;
		}
	}
	GIE = 1;
}

/*******************************************************************************
* Input      : E2_Adress -- E2PROM地址，取值0-127
               *p        -- 待写数据地址
               nByte     -- 写数据个数，取值1-127
* Output     :     	                                
* Description: 
               128Byte E2PROM，1万次write寿命。
               写过程会关闭全局中断。
*******************************************************************************/
void MB86_E2PROM_Read(unsigned char E2_Adress,unsigned char *p,unsigned char nByte)
{
	unsigned char xEADRL,i;
	
	EADRH = 0x20;
	
	xEADRL = E2_Adress;
	if(xEADRL>127)
	{
		return;
	}
	for(i=0; i<nByte; i++)
	{
		EADRL = xEADRL;	
		asm ("MOVP");
		asm ("movwf _xWork");
		*p++ = xWork;
		xEADRL++;
		if(xEADRL > 127)
		{
			return;
		}
	}
	
}






