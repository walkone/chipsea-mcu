﻿#ifndef	_CS_18MB86_Init_H
#define _CS_18MB86_Init_H

//函数声明
extern void IO_Init(void);
extern void Uart_Init(unsigned long baud);
extern void ADC24bit_Init(void);
extern void Timer0_Init(void);
extern void Timer1_Init(void);
extern void MB86_E2PROM_Write(unsigned char E2_Adress,unsigned char *p,unsigned char nByte);
extern void MB86_E2PROM_Read(unsigned char E2_Adress,unsigned char *p,unsigned char nByte);




struct	ADC24bit
{	
	unsigned int SampleRate;
	unsigned int OutputRate;
	unsigned char PGA;
	unsigned int VS;
	int TEMPC;
	unsigned char Enable;
};

struct	TIMER0
{	
	unsigned char TM0CLK_SRC;
	unsigned char TM0CLK_DIV;
	unsigned char TM0IN;
	unsigned char Enable;
};

struct	TIMER1
{	
	unsigned char PWM_HIGH;
	unsigned char TM1CLK_DIV;
	unsigned char TM1IN;
	unsigned char PWM_Enable;
	unsigned char Enable;
};


/*******************************************************************************
* Register      : 
* Address       : 
* Bit Group Name: 
* Permission    : 
*******************************************************************************/
typedef enum {
	ADC24BIT_SAMPLE_RATE_250KHz 		 = 0x00,
	ADC24BIT_SAMPLE_RATE_500KHz 		 = 0b00001000,
} ADC24BIT_SAMPLE_RATE_t;

/*******************************************************************************
* Register      : 
* Address       : 
* Bit Group Name: 
* Permission    : 
*******************************************************************************/
typedef enum {
	ADC24BIT_OUTPUT_RATE_3906Hz 		 = 0b00000000,
	ADC24BIT_OUTPUT_RATE_1953Hz 		 = 0b00000001,
	ADC24BIT_OUTPUT_RATE_976Hz 			 = 0b00000010,
	ADC24BIT_OUTPUT_RATE_488Hz 			 = 0b00000011,
	ADC24BIT_OUTPUT_RATE_244Hz 			 = 0b00000100,
	ADC24BIT_OUTPUT_RATE_122Hz 			 = 0b00000101,
	ADC24BIT_OUTPUT_RATE_61Hz 			 = 0b00000110,
	ADC24BIT_OUTPUT_RATE_30Hz 			 = 0b00000111,
} ADC24BIT_OUTPUT_RATE_t;


/*******************************************************************************
* Register      : 
* Address       : 
* Bit Group Name: 
* Permission    : 
*******************************************************************************/
typedef enum {
	ADC24BIT_PGA_1				 		 = 0b00000000,
	ADC24BIT_PGA_16				 		 = 0b00000100,
	ADC24BIT_PGA_64				 		 = 0b00001000,
	ADC24BIT_PGA_128			 		 = 0b00001100,
} ADC24BIT_PGA_t;

/*******************************************************************************
* Register      : 
* Address       : 
* Bit Group Name: 
* Permission    : 
*******************************************************************************/
typedef enum {
	ADC24BIT_VS_3V			 		 = 0b00000000,
	ADC24BIT_VS_2_8V		 		 = 0b01000000,
	ADC24BIT_VS_2_45V		 		 = 0b10000000,
	ADC24BIT_VS_2_35V		 		 = 0b11000000,
} ADC24BIT_VS_t;


/*******************************************************************************
* Register      : 
* Address       : 
* Bit Group Name: 
* Permission    : 
*******************************************************************************/
typedef enum {
	ADC24BIT_TEMPC_0PPM		 		 = 0b00000000,
	ADC24BIT_TEMPC_45PPM	 		 = 0b00100000,
	ADC24BIT_TEMPC_90PPM	 		 = 0b01000000,
	ADC24BIT_TEMPC_130PPM	 		 = 0b01100000,
	
	ADC24BIT_TEMPC_NEG_45PPM 		 = 0b10100000,
	ADC24BIT_TEMPC_NEG_90PPM 		 = 0b11000000,
	ADC24BIT_TEMPC_NEG_130PPM 		 = 0b11100000,
} ADC24BIT_TEMPC_t;

#endif


