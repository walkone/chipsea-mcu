﻿#include "CSU18MB86.h"

sbit b_rx_ok;

unsigned char tx_buf[20];
unsigned char rx_buf[20];
unsigned char rx_len;
unsigned char rx_sbuf;

/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	
*******************************************************************************/
void uart_send_byte(unsigned char data)
{
    SBUF = data;
    while(!URTIF);
    URTIF = 0;
}


/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	
*******************************************************************************/
void uart_send(unsigned char *buff, unsigned char len)
{
    while (len--)
        uart_send_byte(*buff++);	
}

/*******************************************************************************
* Input      :     	                                                           
* Output     :     	                                
* Description: 	
*******************************************************************************/
void uart_rx_nbyte(void)
{
	rx_len++;
	if(rx_len==1)
	{
		if(rx_sbuf == 0x01)	//header
		{
			rx_buf[0] = rx_sbuf;
		}
		else
		{
			rx_len = 0;	
		}
	}
	else
	{
		rx_buf[rx_len-1] = rx_sbuf;
		if(rx_len >= 7)
		{
			rx_len = 0;
			b_rx_ok = 1;
		}
		
	}
	
}



